SELECT film.title
FROM film
WHERE film.rating = 'PG';

-- select * from film;