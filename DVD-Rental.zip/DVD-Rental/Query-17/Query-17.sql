-- select * from film;

SELECT title
FROM film
WHERE title LIKE '%Adventure%';