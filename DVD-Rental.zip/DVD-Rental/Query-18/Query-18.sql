SELECT *
FROM staff
WHERE store_id = 2;