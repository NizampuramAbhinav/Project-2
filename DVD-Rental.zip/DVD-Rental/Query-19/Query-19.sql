SELECT *
FROM film
WHERE replacement_cost < 20;