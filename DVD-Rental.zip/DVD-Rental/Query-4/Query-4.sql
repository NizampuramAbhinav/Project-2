SELECT film.title, film.rental_rate
FROM film
WHERE film.rental_rate >= 4.99;
