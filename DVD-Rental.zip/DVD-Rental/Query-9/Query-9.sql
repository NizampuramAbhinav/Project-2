select city from city Where city = 'San Diego';

-- select * from city;
