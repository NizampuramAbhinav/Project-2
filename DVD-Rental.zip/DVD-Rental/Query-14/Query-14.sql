select payment_id, customer_id from payment where customer_id = 1;
