-- select store_id from store where store_id = 1;

select film_id,title from film where film_id = 1;

-- select * from film ;