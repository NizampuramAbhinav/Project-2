SELECT title, length
FROM film
WHERE length > 120;
